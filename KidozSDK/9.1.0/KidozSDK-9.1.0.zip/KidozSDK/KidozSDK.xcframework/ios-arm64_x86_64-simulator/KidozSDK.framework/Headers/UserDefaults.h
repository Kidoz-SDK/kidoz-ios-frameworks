//
//  UserDefaults.h
//  KidozSDK
//
//  Created by Lev Firer on 15/11/2017.
//  Copyright © 2017 kidoz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserDefaults : NSObject


+(void)setPublisherID:(NSInteger)id;
+(NSInteger)getPublisherID;

+(void)setSecurityToken:(NSString*)securityToken;
+(NSString*)getSecurityToken;

+(void)setSessionID:(NSInteger)seesionID;
+(NSInteger)getSessionID;
//@property (nonatomic,strong) NSUserDefaults *preferences;

+(void)setKidozSKAdNetworkIdentifierSet:(BOOL)isSet;
+(BOOL)isKidozSKAdNetworkIdentifierSet;

+(void)setSupportedSKADNetworkIds:(NSString*)supportedSKADNetworkIds;
+(NSString*)getSupportedSKADNetworkIds;

+(void)setExtensionType:(NSString*)extensionType;
+(NSString*)getExtensionType;

+(void)setExtensionVersion:(NSString*)extensionVersion;
+(NSString*)getExtensionVersion;





@end
