//
//  KidozApplovinAdapter.h
//  KidozApplovinAdapter
//
//  Created by Maria on 25/06/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for KidozApplovinAdapter.
FOUNDATION_EXPORT double KidozApplovinAdapterVersionNumber;

//! Project version string for KidozApplovinAdapter.
FOUNDATION_EXPORT const unsigned char KidozApplovinAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KidozApplovinAdapter/PublicHeader.h>


