//
//  KidozAdmobAdapter.h
//  KidozAdmobAdapter
//
//  Created by Maria on 25/06/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for KidozAdmobAdapter.
FOUNDATION_EXPORT double KidozAdmobAdapterVersionNumber;

//! Project version string for KidozAdmobAdapter.
FOUNDATION_EXPORT const unsigned char KidozAdmobAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KidozAdmobAdapter/PublicHeader.h>


