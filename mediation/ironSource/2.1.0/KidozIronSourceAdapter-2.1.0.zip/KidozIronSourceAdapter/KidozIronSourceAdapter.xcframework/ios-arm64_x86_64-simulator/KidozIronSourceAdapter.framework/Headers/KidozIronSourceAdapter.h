//
//  KidozIronSourceAdapter.h
//  KidozIronSourceAdapter
//
//  Created by Maria on 25/06/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for KidozIronSourceAdapter.
FOUNDATION_EXPORT double KidozIronSourceAdapterVersionNumber;

//! Project version string for KidozIronSourceAdapter.
FOUNDATION_EXPORT const unsigned char KidozIronSourceAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KidozIronSourceAdapter/PublicHeader.h>
